package mailgun

// Version of current release
const Version = "4.0.0"
